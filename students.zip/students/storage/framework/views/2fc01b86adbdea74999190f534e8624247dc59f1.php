<?php $__env->startSection('head'); ?>
Academy Gallery
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>

<?php $__currentLoopData = $arrpic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<img src="<?php echo e($pics); ?>" alt="" width="300px" height="250">
<br><br><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-mini-first\students\resources\views/students/gallery.blade.php ENDPATH**/ ?>