<?php $__env->startSection('title'); ?>
Edit Student
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>

<form action="/update/<?php echo e($users->id); ?>" method="post">

<?php echo e(method_field('PUT')); ?>

<input type="hidden" name="id" value="<?php echo e($users->id); ?>">
    <div class="form-group">
        <label for="exampleInputEmail1">Name</label>
        <input type="text" class="form-control" id="exampleInputEmail1" name="name" placeholder="Enter name" value="<?php echo e($users->name); ?>">
         <div> <?php echo e($errors->first('name')); ?></div>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Email address</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"  value="<?php echo e($users->email); ?>">
        <div><?php echo e($errors->first('email')); ?> </div>
    </div>


    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" name="password" placeholder="Password"  value="<?php echo e($users->password); ?>">
      <div><?php echo e($errors->first('password')); ?></div>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Mobile</label>
        <input type="number" class="form-control" id="exampleInputEmail1" name="phone" placeholder="Enter mobile number"  value="<?php echo e($users->phone); ?>">
        <div><?php echo e($errors->first('phone')); ?></div>
     </div>

    <button type="submit" name="submit" class="btn btn-primary">Update</button>
    <?php echo csrf_field(); ?>

  </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-mini-first\students\resources\views/students/edituser.blade.php ENDPATH**/ ?>