<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//first section of () it should be the name that will show in url

use App\Citizen;

Route::get('/','studentController@index');
Route::get('/singlestudent/{id}','studentController@profile');
Route::get('/attendance','studentController@attendance');
Route::get('/singleattendance/{id}','studentController@singleattendance');
Route::get('/gallery','studentController@gallery');

//Routes for registration form and saving data to retrive it in second page
// Route::get('/register','CustomerController@list');
// Route::post('/customertable','CustomerController@store');

//Routes for registration form linked to database
// Route::get('/register','CustomerController@show');
Route::get('/register','CustomerController@show');
Route::post('/customertable','CustomerController@insert');
Route::get('/table','CustomerController@list');

Route::get('/edituser/{id}','CustomerController@edit');
Route::put('/update/{id}','CustomerController@update');

Route::get('/deleteuser/{id}','CustomerController@delete');

/////////////////////////////////////////////////////////////////
Route::get('/hana','CitizenController@index');
Route::post('/all','CitizenController@create');
Route::get('/all','CitizenController@show');

route::get('edit/{id}','CitizenController@edit');
Route::post('/update/{id}','CitizenController@update');
route::get('/delete/{id}','CitizenController@destroy');
