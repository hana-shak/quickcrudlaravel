<?php

namespace App\Http\Controllers;

use App\Citizen;
use Illuminate\Http\Request;

class CitizenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('citizen.create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->validate($request,[
            'fullname'    => 'required',
            'gender'      => 'required',
            'city'        => 'required',
            'nid'         => 'required|digits:10',
            'mobile'      => 'required',
            'address'     => 'required',
        ]);
          return $this->store($request);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $citizen = new Citizen();

        $citizen->fullname  = $request->input('fullname');
        $citizen->gender    = $request->input('gender');
        $citizen->city      = $request->input('city');
        $citizen->address   = $request->input('address');
        $citizen->mobile    = $request->input('mobile');
        $citizen->nid       = $request->input('nid');

        $citizen->save();

        return redirect('/all') ;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Citizen  $citizen
     * @return \Illuminate\Http\Response
     */
    public function show(Citizen $citizen)
    {
        // return"Got ya .. ";
        $citizen = Citizen::all();
        return view('citizen.show',compact('citizen'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Citizen  $citizen
     * @return \Illuminate\Http\Response
     */
    public function edit(Citizen $citizen, $id)
    {
        $citizen = Citizen::findOrFail($id);
        return view('citizen.edit',compact('citizen'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Citizen  $citizen
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Citizen $citizen, $id)
    {
        $request->validate([
            'fullname'    => 'required',
            'gender'      => 'required',
            'city'        => 'required',
            'nid'         => 'required|digits:10',
            'mobile'      => 'required',
            'address'     => 'required',

        ]);

        $citizen = Citizen::findOrFail($id);

        $citizen->fullname  = $request->input('fullname');
        $citizen->gender    = $request->input('gender');
        $citizen->city      = $request->input('city');
        $citizen->address   = $request->input('address');
        $citizen->mobile    = $request->input('mobile');
        $citizen->nid       = $request->input('nid');

        $citizen->save();
        return redirect ('/all');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Citizen  $citizen
     * @return \Illuminate\Http\Response
     */
    public function destroy(Citizen $citizen, $id)
    {
        $citizen=Citizen::destroy($id);
        return redirect('/all');
    }
}
