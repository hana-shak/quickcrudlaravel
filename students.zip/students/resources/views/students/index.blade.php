@extends('layouts.master')

@section('title')
Home
@endsection

@section('main')
<div class="row mt-5">
@foreach ($arrstudent as $key => $students)
<div class="col-md-2 card m-3 " style="width: 18rem;">
    <img class="card-img-top" src="{{$students['image']}}" alt="Card image cap">
    <div class="card-body d-flex flex-column">
      <h5 class="card-title">{{$students['name']}}</h5>
      <a href="singlestudent/{{$key}}" class="mt-auto btn btn-warning btn-sm d-flex justify-content-center">View Profile</a>
    </div>
  </div>

{{-- <img src="{{$students['image']}}" alt="" width="100px" height="100px">
<h5>{{$students['name']}}</h5>
<h5>{{$students['birthday']}}</h5> --}}
@endforeach
</div>
@endsection
