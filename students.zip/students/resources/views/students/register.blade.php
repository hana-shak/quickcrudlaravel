@extends('layouts.master')

@section('title')
Registration
@endsection


@section('main')

<form action="/customertable" method="post">

    <div class="form-group">
        <label for="exampleInputEmail1">Name</label>
        <input type="text" class="form-control" id="exampleInputEmail1" name="name" placeholder="Enter name">
         <div> {{ $errors->first('name')}}</div>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Email address</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
        <div>{{$errors->first('email')}} </div>
    </div>


    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" name="password" placeholder="Password">
      <div>{{$errors->first('password')}}</div>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Mobile</label>
        <input type="number" class="form-control" id="exampleInputEmail1" name="phone" placeholder="Enter mobile number">
        <div>{{$errors->first('phone')}}</div>
     </div>

    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
    @csrf

  </form>
  {{-- <div>{{$info}}</div> --}}
@endsection

