@extends('layouts.master')

@section('head')
Academy Gallery
@endsection


@section('main')

@foreach ($arrpic as $pics)
<img src="{{$pics}}" alt="" width="300px" height="250">
<br><br><br>
@endforeach
@endsection
