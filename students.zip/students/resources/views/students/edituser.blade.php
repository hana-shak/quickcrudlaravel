@extends('layouts.master')

@section('title')
Edit Student
@endsection


@section('main')

<form action="/update/{{$users->id}}" method="post">

{{method_field('PUT')}}
<input type="hidden" name="id" value="{{$users->id}}">
    <div class="form-group">
        <label for="exampleInputEmail1">Name</label>
        <input type="text" class="form-control" id="exampleInputEmail1" name="name" placeholder="Enter name" value="{{$users->name}}">
         <div> {{ $errors->first('name')}}</div>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Email address</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"  value="{{$users->email}}">
        <div>{{$errors->first('email')}} </div>
    </div>


    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" name="password" placeholder="Password"  value="{{$users->password}}">
      <div>{{$errors->first('password')}}</div>
    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Mobile</label>
        <input type="number" class="form-control" id="exampleInputEmail1" name="phone" placeholder="Enter mobile number"  value="{{$users->phone}}">
        <div>{{$errors->first('phone')}}</div>
     </div>

    <button type="submit" name="submit" class="btn btn-primary">Update</button>
    @csrf

  </form>

@endsection

